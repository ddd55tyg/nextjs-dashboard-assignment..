import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'

export const fetchData = createAsyncThunk('data/fetch', async () => {
  const rows = Array.from({ length: 137 }).map((_, i) => ({
    id: i + 1,
    name: `User ${i + 1}`,
    email: `user${i + 1}@example.com`,
    value: Math.round(Math.random() * 1000),
    date: new Date(Date.now() - i * 86400000).toISOString().slice(0, 10)
  }))
  return rows
})

const dataSlice = createSlice({
  name: 'data',
  initialState: { items: [], status: 'idle' },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchData.pending, (s) => { s.status = 'loading' })
      .addCase(fetchData.fulfilled, (s, a) => { s.status = 'succeeded'; s.items = a.payload })
      .addCase(fetchData.rejected, (s) => { s.status = 'failed' })
  }
})

export default dataSlice.reducer
