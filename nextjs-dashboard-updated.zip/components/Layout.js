export default function Layout({ children }) {
  return (
    <div className='min-h-screen bg-slate-100 p-4'>
      <div className='max-w-6xl mx-auto'>
        <header className='mb-4 flex items-center justify-between'>
          <h1 className='text-2xl font-bold'>Dashboard</h1>
          <div className='text-sm'>Admin</div>
        </header>
        {children}
      </div>
    </div>
  )
}
