import React, { useMemo, useState, useEffect } from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { fetchData } from '../store/dataSlice'
import { exportToXLSX, exportToPdf } from '../utils/export'

export default function DataTable() {
  const dispatch = useDispatch()
  const items = useSelector((s) => s.data.items)
  const status = useSelector((s) => s.data.status)
  const [page, setPage] = useState(1)
  const [perPage] = useState(10)
  const [query, setQuery] = useState('')
  const [sort, setSort] = useState({ field: 'id', dir: 'asc' })

  useEffect(() => { if (status === 'idle') dispatch(fetchData()) }, [status, dispatch])

  const filtered = useMemo(() => {
    let data = items
    if (query) data = data.filter(d => d.name.toLowerCase().includes(query.toLowerCase()) || d.email.toLowerCase().includes(query.toLowerCase()))
    const cmp = (a,b) => (a[sort.field] > b[sort.field]) ? 1 : (a[sort.field] < b[sort.field]) ? -1 : 0
    data = data.slice().sort((a,b) => sort.dir === 'asc' ? cmp(a,b) : -cmp(a,b))
    return data
  }, [items, query, sort])

  const total = filtered.length
  const pages = Math.max(1, Math.ceil(total / perPage))
  const paged = filtered.slice((page-1)*perPage, page*perPage)

  return (
    <div className='p-4 bg-white rounded shadow'>
      <div className='flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2'>
        <div className='flex gap-2'>
          <input value={query} onChange={e=>{setQuery(e.target.value); setPage(1)}} placeholder='Search name or email' className='border p-2 rounded' />
          <select onChange={e=>setSort({ field: e.target.value, dir: sort.dir })} value={sort.field} className='border p-2 rounded'>
            <option value='id'>ID</option>
            <option value='name'>Name</option>
            <option value='value'>Value</option>
            <option value='date'>Date</option>
          </select>
          <button onClick={() => setSort(s => ({...s, dir: s.dir==='asc'?'desc':'asc'}))} className='px-3 py-2 border rounded'>Sort {sort.dir}</button>
        </div>
        <div className='flex gap-2'>
          <button onClick={() => exportToXLSX(filtered)} className='px-3 py-2 border rounded'>Export XLSX</button>
          <button onClick={() => exportToPdf(filtered)} className='px-3 py-2 border rounded'>Export PDF</button>
        </div>
      </div>

      <div className='overflow-x-auto mt-4'>
        <table className='w-full table-auto text-sm'>
          <thead>
            <tr className='text-left'>
              <th className='p-2'>ID</th>
              <th className='p-2'>Name</th>
              <th className='p-2'>Email</th>
              <th className='p-2'>Value</th>
              <th className='p-2'>Date</th>
            </tr>
          </thead>
          <tbody>
            {paged.map(r => (
              <tr key={r.id} className='odd:bg-gray-50'>
                <td className='p-2'>{r.id}</td>
                <td className='p-2'>{r.name}</td>
                <td className='p-2'>{r.email}</td>
                <td className='p-2'>{r.value}</td>
                <td className='p-2'>{r.date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className='flex items-center justify-between mt-4'>
        <div>Showing {(page-1)*perPage + 1} - {Math.min(page*perPage, total)} of {total}</div>
        <div className='flex gap-2'>
          <button className='px-3 py-1 border rounded' onClick={() => setPage(p => Math.max(1, p-1))}>Prev</button>
          <div className='px-3 py-1 border rounded'>{page}/{pages}</div>
          <button className='px-3 py-1 border rounded' onClick={() => setPage(p => Math.min(pages, p+1))}>Next</button>
        </div>
      </div>
    </div>
  )
}
