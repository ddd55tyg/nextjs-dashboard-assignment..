export default function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()
  const { username, password } = req.body || {}
  if (username === 'admin' && password === 'password') {
    return res.status(200).json({ token: 'mock-token-123', user: { name: 'Admin' } })
  }
  return res.status(401).json({ error: 'Invalid credentials' })
}
