import { useState } from 'react'
import { useRouter } from 'next/router'

export default function Login() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState(null)
  const router = useRouter()

  async function submit(e) {
    e.preventDefault()
    setError(null)
    const res = await fetch('/api/auth', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    })
    if (res.ok) {
      const data = await res.json()
      // simple store token in localStorage for demo
      localStorage.setItem('token', data.token)
      router.push('/')
    } else {
      const err = await res.json()
      setError(err.error || 'Login failed')
    }
  }

  return (
    <div className='min-h-screen flex items-center justify-center bg-slate-100 p-4'>
      <form onSubmit={submit} className='bg-white p-6 rounded shadow w-full max-w-md'>
        <h2 className='text-xl font-semibold mb-4'>Sign in</h2>
        <label className='block mb-2'>Username</label>
        <input value={username} onChange={e=>setUsername(e.target.value)} className='w-full p-2 border rounded mb-3' />
        <label className='block mb-2'>Password</label>
        <input type='password' value={password} onChange={e=>setPassword(e.target.value)} className='w-full p-2 border rounded mb-3' />
        {error && <div className='text-red-600 mb-3'>{error}</div>}
        <button className='w-full bg-blue-600 text-white py-2 rounded'>Sign in</button>
      </form>
    </div>
  )
}
