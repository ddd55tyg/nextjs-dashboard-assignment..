import Layout from '../components/Layout'
import DataTable from '../components/DataTable'
import ChartComp from '../components/ChartComp'
import { useSelector } from 'react-redux'

export default function Home() {
  const items = useSelector(s => s.data.items)
  const chartData = items.slice(0, 30).map(i => ({ date: i.date, value: i.value })).reverse()

  return (
    <Layout>
      <div className='grid grid-cols-1 lg:grid-cols-3 gap-4'>
        <div className='lg:col-span-2'>
          <DataTable />
        </div>
        <div>
          <ChartComp data={chartData} />
        </div>
      </div>
    </Layout>
  )
}
