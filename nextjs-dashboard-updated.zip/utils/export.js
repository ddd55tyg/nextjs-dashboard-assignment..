import * as XLSX from 'xlsx'
import { saveAs } from 'file-saver'
import jsPDF from 'jspdf'

export function exportToXLSX(rows, filename = 'export.xlsx') {
  const ws = XLSX.utils.json_to_sheet(rows)
  const wb = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(wb, ws, 'Sheet1')
  const buf = XLSX.write(wb, { bookType: 'xlsx', type: 'array' })
  saveAs(new Blob([buf], { type: 'application/octet-stream' }), filename)
}

export function exportToPdf(rows, filename = 'export.pdf') {
  const doc = new jsPDF()
  const top = 10
  doc.setFontSize(12)
  let y = top
  const cols = Object.keys(rows[0] || {}).slice(0, 5)
  doc.text(cols.join(' | '), 10, y)
  y += 6
  rows.slice(0, 50).forEach(r => {
    const line = cols.map(c => String(r[c]).slice(0, 20)).join(' | ')
    doc.text(line, 10, y)
    y += 6
    if (y > 280) { doc.addPage(); y = top }
  })
  doc.save(filename)
}
